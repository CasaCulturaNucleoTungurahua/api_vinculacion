INSERT INTO public.favorites (id) VALUES (1);
