INSERT INTO public.agenda (id, imageurl, title) VALUES (6, 'https://culturatungurahua.com/wp-content/uploads/2023/06/J21.jpg', 'Curso Vacacional');
INSERT INTO public.agenda (id, imageurl, title) VALUES (8, 'https://culturatungurahua.com/wp-content/uploads/2023/06/J22.jpg', 'Vacacionales de Salsa');
INSERT INTO public.agenda (id, imageurl, title) VALUES (9, 'https://culturatungurahua.com/wp-content/uploads/2023/06/J20.jpg', 'Curso Vacacional de Violín');
INSERT INTO public.agenda (id, imageurl, title) VALUES (7, 'https://culturatungurahua.com/wp-content/uploads/2023/06/J23.jpg', 'Pelileo Rock Fest');
