INSERT INTO public.favorites_artworks (favorites_id, artworks_code) VALUES (1, 'T.6.4-8.0093-1');
INSERT INTO public.favorites_artworks (favorites_id, artworks_code) VALUES (1, 'T.4.4-7.0039-1');
INSERT INTO public.favorites_artworks (favorites_id, artworks_code) VALUES (1, 'T.5.4-8.0165-1');
INSERT INTO public.favorites_artworks (favorites_id, artworks_code) VALUES (1, 'T.4.4-13.0033-1');
